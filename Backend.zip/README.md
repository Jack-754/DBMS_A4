# DBMS_Spring_24-25
DBMS_Spring_24-25
https://docs.google.com/document/d/17YWLG6Fn3u_Hvwg6H395K3Aph_uKNd3TJr0C6pK0H88/edit?usp=sharing
Functional Requirements

1. Login
2. Home page
    1. Shows menus as tiles
3. Register Portal
4. Only Employees be allowed to modify data
5. Get various info for citizen
6. For government monitors shows statistics

Menus —
	1.  Citizen — 
			Profile  
			Assets 
			Tax filing  
			Certificate 
			Income Declarations 
			Available Schemes
			Enrolled Schemes
	2. Employees —  Super Power
			Profile
			Certificate Request
			And others
	3. System Administrator — 
			User List with remove button
	4. Government monitors — 
			Profile
			Name of Panchayat employees and details
			Government assets
			Government Schemes
			Taxes
			Census Data
			Agricultural Data
			Environment Data
		

Login, login out , registration, Session, 


app.py
endpoint.txt

##USE THE EXISTING CODE AS TEMPLATE FOR CREATING REQUIRED ENDPOINTS



